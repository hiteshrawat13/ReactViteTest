class Helper{
    constructor(){
        
    }

    hi(){
        alert("EE")
        
    }

    getPreview(){
        console.log("preview server");
          return "DDDDDDDDDDDDDDDDD"
    }

    publish(){
        console.log("hi server");

        return "DDDDDDDDDDDDDDDDD"
    }
}


export {Helper} ;
const isLoggedIn=()=>{
    return sessionStorage.getItem("user");
}

const checkLogin=()=>{
  const user =  sessionStorage.getItem("user")
}

const login=(empId,password)=>{

}
export default  campaigns=()=>[
    {
        type:"campaign",
        touch:"1st-touch",
        name:"TGIF"
    },
    {
        type:"campaign",
        touch:"1st-touch",
        name:"TGIF"
    }
]
const getEDMHtml=()=>{
     return "EDM html"
}

const getLandingHtml=()=>{
    return "Landing html"
}

export {
    getEDMHtml,
    getLandingHtml
};
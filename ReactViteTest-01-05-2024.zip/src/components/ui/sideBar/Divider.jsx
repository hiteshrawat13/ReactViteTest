import React from 'react'

import './Divider.scss'
const Divider = () => {
  return (
    <div className='Divider'></div>
  )
}

export default Divider
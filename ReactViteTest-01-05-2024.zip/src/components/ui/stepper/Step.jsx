import React from 'react'

const Step = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default Step
import React, { useState } from 'react'

import './CreateCampaign.scss'
import { useNavigate } from 'react-router-dom/dist'
import Modal from '../../components/ui/Modal'
const CreateCampaign = () => {
  const [isOpened,setOpened]=useState(false)
    const navigate=useNavigate()


    const handleClick=(path)=>{
        
        navigate(`/campaigns/create/${path}`)
    }

  return (

    <>
    <div>CreateCampaign</div>

    <div className='cardHolder'>
        <div className='campaignCard' onClick={()=>handleClick("TGIF")} >
          
          <div className='title'>TGIF</div>
          <div className='server'>resource.itbusinesstoday.com</div>
        </div>
        <div className='campaignCard' onClick={()=>handleClick("Alpha")} >
          <div className='title'>Alpha</div>
          <div className='server'>resource.itbusinesstoday.com</div>
        </div>
        <div className='campaignCard' onClick={()=>handleClick("Arc")} > 
          <div className='title'>Arc</div>
          <div className='server'>resource.itbusinesstoday.com</div>
        </div>
        <div className='campaignCard' onClick={()=>handleClick("EBN")}>
          <div className='title'>EBN</div>
          <div className='server'>resource.itbusinesstoday.com</div>
        </div>
    </div>
   

   
{isOpened && 
<Modal setOpened={setOpened} title={"My Modal"}>
  
  <div><label>First Name</label><input /></div>
  
  
  </Modal>}

<button className='openModal' onClick={()=>setOpened(true)}>Open Modal</button>

    
    </>
    
  )
}

export default CreateCampaign
import React, { useEffect } from 'react'
import AdvancedDataTable from './AdvancedDataTable'

const MyCampaigns = () => {

    

  return (
    <div>
       <AdvancedDataTable/>
    </div>
  )
}

export default MyCampaigns
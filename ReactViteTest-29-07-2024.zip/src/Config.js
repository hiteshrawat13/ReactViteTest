const Config={}
//Config.API_BASE_URL="http://localhost:8888";



Config.API_BASE_URL="http://192.168.1.14:8888";


//home: http://192.168.1.14:9090/cbtool/
//dont forget to change sequalize pass in backend
export default Config;
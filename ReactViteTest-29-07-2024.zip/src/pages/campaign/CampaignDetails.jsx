import React from 'react'

import HDataTable from '../../components/ui/dataTable/HDataTable'
const CampaignDetails = () => {
  return (
    <>
    
    <HDataTable/>
    <div>wewe we we </div>

    </>
  )
}

export default CampaignDetails